#define WIFI_SSID 0
#define WIFI_PASSWORD 1

#define LED1 4
#define LED2 16
#define LED3 17


#define VN 39
#define IO34  34
#define VP  36